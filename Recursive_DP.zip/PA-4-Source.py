'''
PA-4 -- Patrick Fruge
This code is intended to show the number of ways to traverse a staircase depending on the user input of number of steps, 
number of types of leaps and the length of the leap.

The intention of this program is to show the time that it takes to traverse the code recursively and utilizing dynamic programming.
GeeksforGeeks and w3schools were big helps in coding this

Both algorithms work as intended, but I was not able to code the printing of the possible ways that you can traverse a staircase.
I originally was trying to modulate the total step with all possible step types, but it was getting out of control quickly. 
I would like to know if I was on the right track or not if you have done this before.


'''

import timeit as ti      # Importing library for using a timer


def Recursive_Alg(n, ways_to_climb_list):
    if n < 0:
        return 0
    elif n == 0:    # setting base case
        return 1
    elif n in ways_to_climb_list:   
        return 1 + sum(Recursive_Alg(n - x, ways_to_climb_list) for x in ways_to_climb_list if x < n) # add the number of ways to climb as long as x is less than n
    else:
        return sum(Recursive_Alg(n - x, ways_to_climb_list) for x in ways_to_climb_list if x < n)

def Dynamic_Alg(n, ways_to_climb_list):
    # step_ways[i] contains number of ways to step i with the set of different leaps
    step_ways = [0 for _ in range(n + 1)]
    step_ways[0] = 1
    for i in range(n + 1): # for loop from index 0 to n (from user input)
        step_ways[i] += sum(step_ways[i - x] for x in ways_to_climb_list if i - x > 0) 
        step_ways[i] += 1 if i in ways_to_climb_list else 0
    return step_ways[-1] # return the end


def menu():
    # list of steps at a time
    ways_to_climb_list = []
    ways_to_climb = 0

    # get number of steps in staircase and different possible leaps
    n = int(input("Enter the number of steps the staircase has: "))
    ways_to_climb = int(input("How many different number of ways will we traverse the stairs? "))

    if ways_to_climb not in range(2, n + 1):        # verifying cardinality is from 2 to n
        while ways_to_climb not in range(2, n + 1):
            ways_to_climb = int(input("Invalid number (cardinality has to be 2 to {}) choose again: ".format(n))) # Makes sure no decimal places

    #get set of steps allows in each leap
    for i in range(ways_to_climb):
        x = int(input("Way " + str(i + 1) + "(steps allowed in each leap): "))
        # check value range is valid
        if x > n:
            while x > n:
                x = input("Value range has to be from 1 to {} choose again: ".format(n))
        ways_to_climb_list.append(x)

    # time algorithms 
    start_time_recursive = ti.default_timer()
    Recursive_Alg(n, ways_to_climb_list)
    end_time_recursive = ti.default_timer()

    final_time_recursive = (end_time_recursive - start_time_recursive) * 1000000 

    start_time_dynamic = ti.default_timer()
    Dynamic_Alg(n, ways_to_climb_list)
    end_time_dynamic = ti.default_timer()

    final_time_dynamic = (end_time_dynamic - start_time_dynamic) * 1000000

    print("\nThe time elapsed in the recursive algorithm is {:.2f} (microseconds)".format(final_time_recursive))    # print the total time for recursive
    print("The time elapsed in the non-recursive algorithm is {:.2f} (microseconds)".format(final_time_dynamic))    # print the total time for dynamic
    print("There are a total of {} ways \n".format(Dynamic_Alg(n, ways_to_climb_list)))

def main():     # defining loops to continue user input choices
    choice = "Yes"
    while choice == "Yes" or choice == "yes" or choice == "Y" or choice == "y":  # Giving different possible yes so that user doesn't break code
        menu()
        choice = input("Would you like to run the algorithm again? Please indicate yes or no:    ")
    print("Thank you, Goodbye! ")

def txtFile():  # creating a txt file for deliverable
    f = open("PA-4-Efforts.txt", "w")
    f.write("To run the program, simply use the executable file that is provided \n")
    f.write("Group member contribution: \n")
    f.write("Patrick Fruge : 100 %")
    f.close()

################################################################# END OF FUNCTIONS ########################################################################

print("Hello, this program will figure out how many different ways you can traverse ")
print("a set of stairs depending on the number of steps and the different step sizes you take.")
main()  # initiate the program

txtFile() # create txt file for required deliverable