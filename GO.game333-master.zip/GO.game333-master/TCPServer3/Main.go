package main

func main() {

	InitializeServer()

}
