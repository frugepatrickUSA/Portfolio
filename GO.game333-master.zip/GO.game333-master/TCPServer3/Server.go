package main

import (
	"bufio"
	"fmt"
	"net"
)

var numClients = 0
var clients = make([]Connection, 2)
var clientActions = make(chan ClientAction)

type Connection struct {
	clientNum int
	conn      net.Conn
}

//For each msg client sends, want to add it to the "clientActions" channel to be processed individually.
//Need "ClientAction" that contains msg and who sent it.
type ClientAction struct {
	message string
	conn    net.Conn
}

// Check is a method that will panic on an error, or print a successful message and continue
func Check(err error, message string) {
	if err != nil {
		panic(err)
	}
	fmt.Printf("%s\n", message)
}

func AcceptConnection(ln net.Listener) (conn net.Conn) {
	c, e := ln.Accept()
	Check(e, "Accepted connection.")
	fmt.Println(c)
	return c
}

func AddClient(connIn net.Conn) {
	numClients++
	newConnection := Connection{
		clientNum: numClients,
		conn:      connIn,
	}
	clients[numClients-1] = newConnection
	println("Currently connected clients:")
	fmt.Println(clients)
}

func clientThread(conn net.Conn, currentClients []Connection) {
	// buf := bufio.NewReader(conn)

	// //Inside each connection, we want to iterate the communication, starting with reading the name sent to the server:
	// for {
	// 	msg, err := buf.ReadString('\n')

	// 	//err is created if client disconnects. This will break from the for loop.
	// 	if err != nil {
	// 		fmt.Printf("Client disconnected.\n")
	// 		break
	// 	}
	// 	// for i := range clients {
	// 	// 	clients[i].conn.Write([]byte("Hello, " + msg))
	// 	// }
	// 	conn.Write([]byte("Hello, " + msg))

	// }
}

//Function that will listen to the "clientActions" channel
// func ProcessResponses(clientActions chan ClientAction, clients []Connection) {
// 	for {
// 		//Waits for next action to come off queue from clientActions channel
// 		clientAction := <-clientActions
// 		msg := clientAction.message

// 		for i := range clients {
// 			clients[i].conn.Write([]byte("Hello, " + msg))
// 		}

// 		//clientAction.conn.Write([]byte("Hello, " + clientAction.message))
// 	}
// }

// func ReceiveMessages(clients []Connection) {
// 	data, err := bufio.NewReader(conn).ReadString('\n')
// 	if err != nil {
// 		fmt.Println(err)
// 		return
// 	}
// 	for i := range clients {
// 		clients[i].conn.Write([]byte("Hello, " + data))
// 	}
// }

func a(clients []Connection) {
	buf := bufio.NewReader(clients[0].conn)

	data, err := buf.ReadString('\n')

	if err != nil {
		fmt.Printf("Client disconnected.\n")
		break
	}
	clients[0].conn.Write([]byte("Hello, " + data))
	clients[1].conn.Write([]byte("Hello, " + data))
}

func acceptClients(ln net.Listener) {
	conn := AcceptConnection(ln)
	AddClient(conn)
}

func InitializeServer() {
	//clients := make([]net.Conn, 2)
	//go ProcessResponses(clientActions, clients)

	port := ":5555"
	fmt.Println("Port number for clients: " + port)

	//Start listening for clients
	ln, err := net.Listen("tcp", port)
	Check(err, "Server is ready. Waiting for connections...")

	//To accept multiple simultaneous connections, need to iterate the Accept for each new client connection coming in
	for {

		go acceptClients(ln)

		//conn := AcceptConnection(ln)
		//AddClient(conn)

		go a(clients)
		// go func() {
		// 	buf := bufio.NewReader(conn)

		// 	for {
		// 		data, err := buf.ReadString('\n')

		// 		if err != nil {
		// 			fmt.Printf("Client disconnected.\n")
		// 			break
		// 		}
		// 		clients[0].conn.Write([]byte("Hello, " + data))
		// 		clients[1].conn.Write([]byte("Hello, " + data))
		// 		//clientActions <- ClientAction{data, conn}
		// 	}
		// }()
	}
	//go clientThread(conn, clients)
	//go ReceiveMessages(clients)
}
