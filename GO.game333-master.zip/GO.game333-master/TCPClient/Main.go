package main

func main() {

	InitializeClient()

}
