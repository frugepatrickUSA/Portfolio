/*		Patrick Fruge					CSC231 'Create a Class Assignment'
* The point of this code is to practice with designing classes. This file will create a class of cranes.
* It will establish the name, color, ID and size using member functions. The files are separated into header, cpp and main.cpp files.
*
*/

#include <iostream>
#include <string>
#include "Crane.h"


using namespace std;

int main()
{
	cout << "***********************************************************************" << endl;
	cout << "\t \t" << "Please select an option from the list below: " << endl << endl;
	cout << "\t 1) Add a new entry to the front of the list " << endl;
	cout << "\t 2) Add a new entry to the back of the list " << endl;
	cout << "\t 3) Search for and display a specific item in the list " << endl;
	cout << "\t 4) Edit a specified item from the list " << endl;
	cout << "\t 5) Remove an identified item from the list  " << endl;
	cout << "\t 6) Display the entire list " << endl;
	cout << "\t 7) End the Program " << endl;
	cout << "***********************************************************************" << endl << endl << endl;


	Crane Crane1; // creating the class in the main.cpp

	/* Member functions to set the attributes
	Crane1.setCraneProblem("Crane 1");
	Crane1.setCraneSolution("Yellow");
	Crane1.setCraneID(1001);
	Crane1.setCraneSize(100); */

	//Utility function to print to the screen.
	Crane1.print();


	return 0;

}