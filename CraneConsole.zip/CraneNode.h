#ifndef CRANENODE_H
#define CRANENODE_H

#include "Crane.h"

class CraneNode
{
public:
	CraneNode();
	~CraneNode(); //Destructor

private:
	Crane crane;
	CraneNode* Prev;	// Establishing both nodes for double linked
	CraneNode* Next;
	friend class CraneList;	// Allowing the list to access the private variables in this class
};
#endif

CraneNode::CraneNode()
{
}

CraneNode::~CraneNode()
{
}