/*		Patrick Fruge					CSC231 'Create a Class Assignment'
*This Header file is the .h file that houses the class creation and function calls that correspond to
* The class' capabilities.
*
*/


#ifndef Crane_H
#define Crane_H

#include <iostream>
#include <string>	// So that I can use string functions

// So as to not use the whole std library, I have only used the small amount I will need in this class.
using std::string;
using std::cout;
using std::endl;


class Crane
{
private:
	string Problem;
	string Solution;
	int ID;
	int size;

public:
	//default constructor
	Crane();

	//get and set functions
	string getCraneProblem();
	string getCraneSolution();
	int getCraneID();
	int getCraneSize();
	void setCraneProblem(string CraneProblem);
	void setCraneSolution(string CraneSolution);
	void setCraneID(int CraneID);
	void setCraneSize(int Cranesize);

	//utility function
	void print();

};

#endif 