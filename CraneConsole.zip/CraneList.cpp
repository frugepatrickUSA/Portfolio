#include "CraneList.h"

#include <iostream>
#include <string>	// So that I can use string functions

// So as to not use the whole std library, I have only used the small amount I will need in this class.
using std::string;
using std::cout;
using std::endl;

CraneList::CraneList()
	: head(NULL), tail(NULL) {}
	
CraneList::~CraneList()	//Deconstructor
{
	while (!IsEmpty())		// If Head == NULL there are no other links in the list
	{
		RemoveFront();
	}
}
bool CraneList::IsEmpty()
{
	return (head == NULL);
}

const Crane& CraneList::Top() const
{
	return head->crane;
}

void CraneList::addFront(const Crane& e)
{
	CraneNode* TempNode = new CraneNode;	//Creating a new node
	TempNode->crane = e;					// I think what this is saying is that the Temporary Node we created
											// is housing a value that we will pass it. 
	TempNode->Next = head;					// Our 'Next' Pointer is pointing to the head.
	if (IsEmpty()) {						// Check if it is empty
		tail = TempNode;
	}
	head = TempNode;		// Replaces the Head = NULL with our new Node
}

void CraneList::addBack(const Crane& e) 
{
	CraneNode* TempNode = new CraneNode;
	TempNode->crane = e;

	TempNode->Next = NULL;
	if (IsEmpty()) {		// If Head == NULL there are no other links in the list
		tail = NULL;
		head = TempNode;
	}
	else {
		tail->Next = TempNode;
		TempNode->Prev = tail; 
	}
	tail = TempNode;
}

void CraneList::RemoveFront() 
{
	if (!IsEmpty()) {		// If Head == NULL there are no other links in the list
		CraneNode* temp = head;
		head = temp->Next;
		delete temp;
	}
}
void CraneList::SearchandDisplay(string key)
{
	CraneNode* temp = head;
	if (IsEmpty()) {		// If Head == NULL there are no other links in the list
		cout << "There are no entries to list" << endl;
		return;
	}
 // Patrick...you pass in a string as key but then you tried comparing it to an integer
 // You cannot do that unless you overrided the == operator someplace and tell it how to do it.
 // What you wanted was a int, not a string. I converted it to a int for the comparison but you may want to change it to be an int in the first place.
 // Not sure what all you are comparing though. I did not check all the logic, just fixed the compile bug.
	while (temp != NULL) { // when temp == NULL you will break out of the loop after comparing all elements
		if (temp->crane.getCraneID() == stoi(key)) {  // you were comparing integer to a string which caused the error
			cout << "The Search was successful!" << endl;
			cout << temp->crane.getCraneID() << endl;
			return;
		}
		temp = temp-> Next; //Keep moving through the list checking for the item
	}
	cout << "Print out that whatever you were looking for was not found\n";
   return;
}
void CraneList::EditItem()
{

}
void CraneList::RemoveItem(string key)
{
	CraneNode* temp = head;
	if (IsEmpty()) {
		cout << "There are no items currently in the list" << endl;
	}
	//if ()
		//;	// Use string to identify previous link and change the place pointer to point to new link?

	//delete
}		
void CraneList::DisplayList()
{
	if (IsEmpty()) {
		cout << "There are no Cranes currently logged in the list" << endl; //Return NULL means no items in list
	}
	else {
		CraneNode* temp = head;			//Creating a temp pointer 
      
      //Patrick...here you were passing the print function to the cout stream via the << operator but you had not overridden the << operator
      // to allow you to do that. I fixed it by just calling the print function directly and bypassing cout.
		while (temp != NULL) {			// Loop until reach the tail which == NULL
			temp->crane.print();	      // Print the crane that was listed
         cout << endl;
			temp = temp->Next;				// Advance to the next link in the list
		}
	}
}

