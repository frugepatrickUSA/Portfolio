/*		Patrick Fruge					CSC231 'Create a Class Assignment'
* This is the .cpp file that houses the IMPLEMENTATION of the Crane Class.
* Below are getter and setter functions that will allow us to create an identity for each class we create.
*
*/


#include <iostream>
#include <string>
#include "Crane.h"



Crane::Crane()		//constructor
{
}

string Crane::getCraneProblem()
{
	return Problem;
	// allows us to return the name
}

string Crane::getCraneSolution()
{
	return Solution;
	// allows us to return the color
}

int Crane::getCraneID()
{
	return ID;
	// allows us to return the ID
}

int Crane::getCraneSize()
{
	return size;
	// allows us to return the size
}


void Crane::setCraneProblem(string CraneProblem)
{
	Problem = CraneProblem;
	// Sets the Problem
}
void Crane::setCraneSolution(string CraneSolution)
{
	Solution = CraneSolution;
	// Sets the Solution
}

void Crane::setCraneID(int CraneID)
{
	ID = CraneID;
	// Sets the ID
}

void Crane::setCraneSize(int CraneSize)
{
	size = CraneSize;
	// Sets the size
}

// Utility function to print the contents to the screen.
void Crane::print()
{
	std::cout << "The name of the crane is: " << Problem << std::endl;
	std::cout << "The color of the crane is: " << Solution << std::endl;
	std::cout << "The ID of the crane is: " << ID << std::endl;
	std::cout << "The size of the crane is: " << size << std::endl;
}

