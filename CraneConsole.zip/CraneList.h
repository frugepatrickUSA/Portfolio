#ifndef CRANELIST_H
#define CRANELIST_H

#include "CraneNode.h"
#include <string>

class CraneList {

private: 
	CraneNode* head;
	CraneNode* tail;

public: 
	CraneList();		//Creating an empty list
	~CraneList();	// Deconstructor
	bool IsEmpty();
	const Crane& Top() const;
	void addFront(const Crane& e);		// Add node to front
	void addBack(const Crane& e);	// Add node to back
	void RemoveFront();
	void SearchandDisplay(string key);	// Search for and display contents of a node
	void EditItem();		// Change information in a node
	void RemoveItem(string key);		// Delete a node
	void DisplayList();

};
#endif